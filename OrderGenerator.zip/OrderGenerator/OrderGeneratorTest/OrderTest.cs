﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UITest.Extension;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using OrderGenerator;
using Moq;


namespace OrderGeneratorTest
{
    [TestClass]
   public class OrderTest
    {
        [TestMethod]
        public void OrderGenerateTest()
        {
            //**Mock the code when write email coding**//
            //Mock<Suscriber> objSubscriber = new Mock<Suscriber>();
            //objSubscriber.Setup(x => x.NotifyOrder()).Returns(true);

            //**Mock the code when write email coding**//

            Random objRandom = new Random();
            Order objOrder = new Order();
            objOrder.OrderID = Guid.NewGuid().ToString();
            objOrder.ClientName = "Client" + objRandom.Next(1000, 5000).ToString();
            objOrder.Quantity = objRandom.Next(50, 100);
            objOrder.Price = (decimal)objRandom.NextDouble();
            objOrder.CreatedOn = DateTime.UtcNow;
            objOrder.ProcessedOn = DateTime.UtcNow;

            Basket objBasket = new Basket(objOrder);
            bool OrderStatus = objBasket.AddToBasket();
            Assert.AreEqual(OrderStatus, true);
        }
    }
}
