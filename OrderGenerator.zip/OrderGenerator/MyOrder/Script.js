﻿var selectedRow = null;

function onFormSubmit() {
    var formData = readFormData();
    if (selectedRow == null)
        insertNewRecord(formData);
    else
        updateRecord(formData);
    resetForm();
}

function readFormData() {    
    var formData = {};
    formData["orderId"] = document.getElementById("orderId").value;
    formData["account"] = document.getElementById("account").value;
    formData["quantity"] = document.getElementById("quantity").value;
    formData["price"] = document.getElementById("price").value;
    formData["orderBy"] = document.getElementById("orderBy").value;
    formData["orderDate"] = document.getElementById("orderDate").value;
    return formData;
}

function insertNewRecord(data) {
    var table = document.getElementById("orderlist").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);
    cell1 = newRow.insertCell(0);
    cell1.innerHTML = data.orderId;

    cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.accountaccount;

    cell3 = newRow.insertCell(2);
    cell3.innerHTML = data.quantity;

    cell4 = newRow.insertCell(3);
    cell4.innerHTML = data.price;

    cell5 = newRow.insertCell(4);
    cell5.innerHTML = data.orderBy;

    cell6 = newRow.insertCell(5);
    cell6.innerHTML = data.orderDate;

    cell7 = newRow.insertCell(6);
    cell7.innerHTML = `<a onclick="onEdit(this)">Edit</a> <a onclick="onDelete(this)">Delete</a>`;
}

function resetForm()
{
    document.getElementById("orderId").value = "";
    document.getElementById("account").value = "";
    document.getElementById("quantity").value = "";
    document.getElementById("price").value = "";
    document.getElementById("orderBy").value = "";
    document.getElementById("orderDate").value = "";
    selectedRow = null;
}

function onEdit(td)
{
    selectedRow = td.parentElement.parentElement;
    document.getElementById("orderId").value = selectedRow.cells[0].innerHTML;
    document.getElementById("account").value = selectedRow.cells[1].innerHTML;
    document.getElementById("quantity").value = selectedRow.cells[2].innerHTML;
    document.getElementById("price").value = selectedRow.cells[3].innerHTML;
    document.getElementById("orderBy").value = selectedRow.cells[4].innerHTML;
    document.getElementById("orderDate").value = selectedRow.cells[5].innerHTML;
}

function updateRecord(formData)
{
    selectedRow.cells[0].innerHTML = formData.orderId;
    selectedRow.cells[1].innerHTML = formData.account;
    selectedRow.cells[2].innerHTML = formData.quantity;
    selectedRow.cells[3].innerHTML = formData.price;
    selectedRow.cells[4].innerHTML = formData.orderBy;
    selectedRow.cells[5].innerHTML = formData.orderDate;
}

function onDelete(td) {
    if (confirm('Are you sure want to delete this Record ?')) {
        row = td.parentElement.parentElement;
        document.getElementById("orderlist").deleteRow(row.rowIndex);
        resetForm();
    }
}