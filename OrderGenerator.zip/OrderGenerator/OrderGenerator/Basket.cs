﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace OrderGenerator
{
    public class Basket
    {

        Order ObjOrder;
        public Basket(Order _Order)
        {
            ObjOrder = new Order();
            ObjOrder.OrderID = _Order.OrderID;
            ObjOrder.ClientName = _Order.ClientName;
            ObjOrder.Quantity = _Order.Quantity;
            ObjOrder.Price = _Order.Price;
            ObjOrder.CreatedOn = _Order.CreatedOn;
            ObjOrder.ProcessedOn = _Order.ProcessedOn;
        }

        public bool AddToBasket()
        {
            PushToSubcriber();
            return true;
        }

        private bool PushToSubcriber()
        {
            string fileName = AppDomain.CurrentDomain.BaseDirectory + "Order\\" + ObjOrder.OrderID.ToString();
            FileStream file = File.Create(fileName);

            XmlSerializer writer = new XmlSerializer(typeof(Order));
            writer.Serialize(file, ObjOrder);
            ISubscriber objSubscriber = new Suscriber(fileName);

            objSubscriber.NotifyOrder();

            return true;
        }
    }
}
