﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderGenerator
{
    public class Suscriber : ISubscriber
    {
        string FileName = "";
        public Suscriber(string _FileName)
        {
            FileName = _FileName;
        }
        public bool NotifyOrder()
        {
            //Write mail code here and send it to subscriber with the attached file
            return true;
        }
    }
}
