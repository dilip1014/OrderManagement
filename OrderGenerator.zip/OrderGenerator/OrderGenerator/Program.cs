﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.IO;

namespace OrderGenerator
{
    static class Program
    {
        static  ILog log = LogManager.GetLogger("Task");

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            Service1 objsrvc = new Service1();
            objsrvc.OnDebug();
            System.Threading.Thread.Sleep(System.Threading.Timeout.Infinite);
            
            //ServiceBase[] ServicesToRun;
            //ServicesToRun = new ServiceBase[]
            //{
            //    new Service1()
            //};
            //ServiceBase.Run(ServicesToRun);
        }
    }
}
