﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.IO;
using log4net; 

namespace OrderGenerator
{
    public partial class Service1 : ServiceBase
    {
        Timer _timer = null;
        DateTime _lastRun = DateTime.Now;        
        Random objRandom = new Random();
        static protected ILog log = LogManager.GetLogger("Task");

        public Service1()
        {
            InitializeComponent();
        }

        public void OnDebug()
        {
            OnStart(null);
        }
        protected override void OnStart(string[] args)
        {            
            FileInfo fi = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + "log4netNew.xml");
            log4net.Config.XmlConfigurator.Configure(fi);
            log4net.GlobalContext.Properties["host"] = Environment.MachineName;

            log.Debug("Service Started");
         
            _timer = new Timer(objRandom.Next(1000, 10000)); // every 10 second
            _timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
            _timer.Start(); // <- important

        }


        private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            log.Info("Order processing");
            //DateTime startAt = DateTime.Today.AddHours(9).AddMinutes(48);
            DateTime startAt = DateTime.Now;
            if (_lastRun < startAt && DateTime.Now >= startAt)
            {
                // stop the timer 
                _timer.Stop();
                             

                try
                {
                    log.Info("Order Generation has been started");
                    Order objOrder = new Order();
                    objOrder.OrderID = Guid.NewGuid().ToString();
                    objOrder.ClientName = "Client" + objRandom.Next(1000, 5000).ToString();
                    objOrder.Quantity = objRandom.Next(50, 100);
                    objOrder.Price = (decimal)objRandom.NextDouble();
                    objOrder.CreatedOn = DateTime.UtcNow;
                    objOrder.ProcessedOn = DateTime.UtcNow;

                    Basket objBasket = new Basket(objOrder);
                    bool OrderStatus =  objBasket.AddToBasket();
                    log.Info("Order Generated");

                }
                catch (Exception ex)
                {
                    log.Error("This is my error - ", ex);
                }

                _lastRun = DateTime.Now;
                _timer.Start();
            }
        }


        protected override void OnStop()
        {
        }
    }
}
